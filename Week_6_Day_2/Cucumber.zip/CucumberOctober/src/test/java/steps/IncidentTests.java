package steps;

import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.Map;
import java.util.Map.Entry;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IncidentTests {

//	Given set the endpoint
//	And add the auth
//	When send the request
//	Then validate the response
	RequestSpecification request = null;
	Response response = null;

	@And("set the endpoint")
	public void setEndpoint() {
		RestAssured.baseURI = "https://dev134534.service-now.com/api/now/table/incident";
	}

	@And("add the auth")
	public void setauth() {
		RestAssured.authentication = RestAssured.basic("admin", "8E!uv1yn^FPX");
	}

	@And("add the queryParams as {string} and {string}")
	public void queryParams(String key, String value) {
		request = RestAssured.given().queryParam(key, value);
	}

	@And("add the queryParams")
	public void addqueryParams(DataTable dt) {

		Map<String, String> queryMap = dt.asMap();
		request = RestAssured.given().queryParams(queryMap);
		
	}

	@When("send the request")
	public void sendRequest() {
		//request = RestAssured.given();
		response = request.get();
	}

	@When("post the request with short description as {string} and category as {string}")
	public void postRequest(String short_desc, String category) {
		request = RestAssured.given();
		response = request.contentType(ContentType.JSON)
				.body("{\"short_description\":\"" + short_desc + "\",\"category\":\"" + category + "\"}")

				.post();
	}

	@Then("validate the response")
	public void ValidateResponse() {
		response.prettyPrint();
		response.then().assertThat().statusCode(200);
	}

	@When("post the request with file as {string}")
	public void fileUpload(String fileName) {
		response = request.contentType(ContentType.JSON).body(new File("./src/test/resources/" + fileName)).post();
		
	}

	@Then("validate the response as {int}")
	public void validateResposeInt(int code) {
		response.then().log().all().assertThat().statusCode(code);
	}

	@Then("validate the response for below")
	public void validateResposeStringForMulti(Map<String, String> responseFields) { //string responseFields
		for (Entry<String, String> eachEntry : responseFields.entrySet()) {

			response.then().body(eachEntry.getKey(), equalTo(eachEntry.getValue()));

		}

	}

}
