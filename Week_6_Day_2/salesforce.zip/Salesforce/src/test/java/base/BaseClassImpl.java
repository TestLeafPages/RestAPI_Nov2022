package base;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClassImpl {
	public static RequestSpecification request=null;
	public static Response response = null;
	public static String contact_id=null;
	public static String token = null;
	
	
	@BeforeSuite
	public void tokenGeneration() {
		RestAssured.baseURI = "https://login.salesforce.com/services/oauth2/token";
		Response response = RestAssured
			.given()
			.contentType("application/x-www-form-urlencoded; charset=utf-8")
			.formParam("grant_type", "password")
			.formParam("client_id", "3MVG9wt4IL4O5wvKCwDTaM4zhqMVdGtVPU6W1qJ3X5Kyku873xnLFYFaRqO9654Aja.cDeqnFnWROJ7I6UdSR")
			.formParam("client_secret", "34469143ADA2270B45DC179BD6BF00BEA56E6A0F108718F9BFB6CCA3E300A043")
			.formParam("username", "apitestingjuly@testleaf.com")
			.formParam("password", "Testleaf456")
			.post();
			
			token = response.jsonPath().get("access_token");
	}
	
	
	
	@BeforeMethod
	public void setup() {
		RestAssured.baseURI = "https://testleafcom3-dev-ed.my.salesforce.com/services/data/v22.0/sobjects";
		RestAssured.authentication = RestAssured.oauth2(token);
		request = RestAssured.given().contentType(ContentType.JSON);
	}
}
