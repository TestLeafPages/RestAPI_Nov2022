package contact;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Test  {
	
	public static void main(String[] args) {
		RestAssured.baseURI="https://testleafcom3-dev-ed.my.salesforce.com/services/data/v22.0/sobjects";
		RequestSpecification input = RestAssured.given()
				.header("Authorization","Bearer"+"00D5i000009LplO!AQsAQBFUekz6Yt0JPZe58CP3tg2jaPmS1P2m7kSdhBM6VaJktM1UxV.BUhdcK3oUsVPvOYER7lUyOCBlCD3rU3LEFZPb3.Yq")
	
	;
		Response response = input.get();
		response.prettyPrint();
	
	}
}
