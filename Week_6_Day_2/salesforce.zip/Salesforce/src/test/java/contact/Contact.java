package contact;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import base.BaseClassImpl;

public class Contact extends BaseClassImpl{
	
	
	
	@Test(priority=0)
	public void createContact() {
		response = request.body("{\r\n"
				+ "    \"FirstName\":\"David\",\r\n"
				+ "    \"LastName\":\"spoon\"\r\n"
				+ "}").post("/contact");
		response.prettyPrint();	
		contact_id = response.jsonPath().get("id");
		System.out.println(contact_id);
	}
	
	@Test(priority=1)
	public void checkContactName() {
		response = request.get("/contact/"+contact_id);
		response.then().assertThat().statusCode(200).body("Name",Matchers.equalTo("David spoon"));
	}
	
	@Test(priority=2)
	public void updateContact() {
		response = request.body("{\r\n"
				+ "   \"MailingCity\":\"chennai\"\r\n"
				+ "}")
				.patch("/contact/"+contact_id);
	}
	
	@Test(priority=3)
	public void checkMailingcity() {
		response = request.get("/contact/"+contact_id);
		response.then().assertThat().statusCode(200).body("MailingCity",Matchers.equalTo("chennai"));
	}
	
	@Test(priority=4)
	public void checkNameisPresent() {
		response = request.get("/contact");
		response.then().assertThat().statusCode(200).body("recentItems.Id",Matchers.hasItem(contact_id));
	}
	
	

}
