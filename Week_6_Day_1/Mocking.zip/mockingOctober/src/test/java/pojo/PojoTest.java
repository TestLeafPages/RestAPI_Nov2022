package pojo;

public class PojoTest {
	
	
	public static void main(String[] args) {
		PojoMain pm = new PojoMain();
		pm.setFirstName("Rest-Assured");
		pm.setLastName("Automation");
		
		System.out.println(pm.getFirstName());
		System.out.println(pm.getLastName());
	}
	
	

}
