package traversing;



import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TraversingwithSingle {

	@Test
	public void CreateIncident() {

		RestAssured.baseURI = "https://dev134534.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "8E!uv1yn^FPX");
		
		RequestSpecification request = RestAssured
										.given()
										.contentType(ContentType.JSON);
										

		Response response = request.post();
		
		response.prettyPrint();
		
		String sys_id = response.jsonPath().get("result.sys_id");
		
		System.out.println("Sys id value is => "+sys_id);



	}

}
