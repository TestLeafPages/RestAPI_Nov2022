package traversing;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TraversingwithMany {

	@Test
	public void CreateIncident() {

		RestAssured.baseURI = "https://dev134534.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "8E!uv1yn^FPX");
		
		RequestSpecification request = RestAssured
										.given()
										.contentType(ContentType.JSON);
										

		Response response = request.get();
		response.then().log().all();
		
		List<String> list = response.jsonPath().getList("result.sys_id");
		System.out.println("Count of Sys_id = " + list.size());
//		
		
		

		//response.prettyPrint();
//		System.out.println(response.statusCode());

	}

}
