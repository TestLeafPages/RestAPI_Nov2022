package schemaVAlidation;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

public class SchemaValidation {
	
	@Test
	private void schemaTest() {
		RestAssured.baseURI = "https://dev134534.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "8E!uv1yn^FPX");
		//RestAssured.authentication = RestAssured.oauth2("DT8P2E0umZsjIYH0N3ZkDH2Hg23sctzIen-d6vgG7taYAleZMbB51Rx-oE-ZqBnfaJy4L8RpzmfY0kNXsDWFvQ");
		File file = new File("./src/test/resources/schema1.json");
		Response response = RestAssured.given().contentType(ContentType.JSON).post();
		response.prettyPrint();
		response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(file));
		

	}

}
