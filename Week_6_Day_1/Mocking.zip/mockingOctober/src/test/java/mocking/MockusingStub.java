package mocking;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.tomakehurst.wiremock.client.WireMock;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class MockusingStub {
	
	@BeforeMethod
	private void incidentStub() {
		WireMock.stubFor(WireMock.post("/api/now/table/incident")
				.willReturn(WireMock.aResponse()
						.withStatus(201)
						.withHeader("content-type", "application/json")
						.withBody("{\r\n"
								+ "    \"category\":\"software\",\r\n"
								+ "    \"short_description\":\"Post request with string as body\",\r\n"
								+ "    \"caller_id\":\"5137153cc611227c000bbd1bd8cd2006\"\r\n"
								+ "}")));
		}
	
	

	
	@Test
	private void incidentCreation() {
		
		RestAssured.baseURI = "http://localhost:8080/api/now/table/incident";
//		RestAssured.baseURI = "https://dev134534.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "8E!uv1yn^FPX");
		
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.post()
				;
		
		response.then().assertThat().statusCode(201).statusLine("HTTP/1.1 201 Created");
		
		System.out.println(response.statusCode());
		System.out.println(response.statusLine());
		
		response.prettyPrint();
		
	}

}
