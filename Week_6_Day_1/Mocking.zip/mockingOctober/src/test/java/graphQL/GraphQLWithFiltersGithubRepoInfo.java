package graphQL;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class GraphQLWithFiltersGithubRepoInfo {
	
	
	@Test
	public void firstTest() {
		RestAssured.baseURI = "https://api.github.com/graphql";
		//RestAssured.authentication = RestAssured.oauth2("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");
		
		String Query = "{\"query\":\"query($name:String!, $owner:String!) {\\r\\n  viewer {\\r\\n      login\\r\\n  }\\r\\n   \\r\\n     repository(name: $name,owner: $owner) {\\r\\n       createdAt \\r\\n       \\r\\n       \\r\\n       updatedAt \\r\\n       owner {\\r\\n           url\\r\\n       }\\r\\n\\r\\n     }\\r\\n   }\\r\\n\",\"variables\":{\"name\":\"Java8\",\"owner\":\"ShivasubramaniamR\"}}";
		
				
		Response response = RestAssured.given()
				.header("Authorization","Bearer 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")

				.contentType(ContentType.JSON)
				   .body(Query)
				   .post();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
	}

}
