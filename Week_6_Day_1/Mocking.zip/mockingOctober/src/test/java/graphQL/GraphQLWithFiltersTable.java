package graphQL;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class GraphQLWithFiltersTable {
	
	
	@Test
	public void firstTest() {
		RestAssured.baseURI = "https://dev115190.service-now.com/api/now/graphql";
		RestAssured.authentication = RestAssured.preemptive().basic("admin","mEnAF%*g4y2U");
		
		String Query = "{\"query\":\"query($table: String!,$sys_Id: String!) {\\r\\n    GlideLayout_Query {\\r\\n        formLayout(table: $table,sysId: $sys_Id,) {\\r\\n            encodedRecord\\r\\n            sysId\\r\\n            recordValues {\\r\\n                name \\r\\n                displayValue\\r\\n            }\\r\\n        }\\r\\n    }\\r\\n\\r\\n}\",\"variables\":{\"table\":\"change_request\",\"sys_Id\":\"5fb6906d979d111088bf7c80f053af3c\"}}";
		
				
		Response response = RestAssured.given()
				.contentType(ContentType.JSON)
				   .body(Query)
				   .post();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
		System.out.println(response.statusLine());
	}

}
