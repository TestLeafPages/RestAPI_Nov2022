package graphQL;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class GraphQLWithFiltersGithub {
	
	
	@Test
	public void firstTest() {
		RestAssured.baseURI = "https://api.github.com/graphql";
		RestAssured.authentication = RestAssured.oauth2("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");
		
		String Query = "{\"query\":\"query($number_of_repos:Int!) {\\r\\n  viewer {\\r\\n    name\\r\\n     repositories(last: $number_of_repos) {\\r\\n       nodes {\\r\\n         name\\r\\n       }\\r\\n     }\\r\\n   }\\r\\n}\",\"variables\":{\"number_of_repos\":4}}";
		
				
		Response response = RestAssured.given()
				.contentType(ContentType.JSON)
				   .body(Query)
				   .post();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
	}

}
